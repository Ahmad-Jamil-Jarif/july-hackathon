"use client"

import { useEffect, useMemo, useState } from "react"
import { ChartBar, Clock, Buildings, Star, ArrowRight } from "@phosphor-icons/react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useT } from "@/lib/i18n/context"

interface ProjectMilestone {
  id: string
  title: string
  dueDate: string
  status: "Pending" | "In Progress" | "Verified"
}

interface ProjectDeliverable {
  id: string
  title: string
  ministry: string
  department?: string
  status: "Planning" | "In Progress" | "On Hold" | "Completed"
  progress: number
  deadline: string
  owner: string
  budgetAllocatedBdt?: number
  budgetSpentBdt?: number
  milestones: ProjectMilestone[]
  followers?: string[]
}

const statusStyles: Record<string, string> = {
  Planning: "bg-blue-100 text-blue-700",
  "In Progress": "bg-amber-100 text-amber-700",
  "On Hold": "bg-orange-100 text-orange-700",
  Completed: "bg-green-100 text-green-700",
}

const progressBarColor: Record<string, string> = {
  Planning: "bg-blue-400",
  "In Progress": "bg-amber-400",
  "On Hold": "bg-orange-400",
  Completed: "bg-green-500",
}

export default function ProjectTrackerPage() {
  const t = useT().projects
  const [projects, setProjects] = useState<ProjectDeliverable[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [filter, setFilter] = useState<"all" | "Planning" | "In Progress" | "On Hold" | "Completed">("all")
  const [page, setPage] = useState(1)
  const pageSize = 8

  const userId = useMemo(() => {
    if (typeof window === "undefined") return "anonymous"
    const existing = window.localStorage.getItem("sohojatra_user_id")
    if (existing) return existing
    const next = `citizen-${Math.random().toString(36).slice(2, 10)}`
    window.localStorage.setItem("sohojatra_user_id", next)
    return next
  }, [])

  useEffect(() => {
    let cancelled = false
    async function load() {
      try {
        const res = await fetch("/api/projects", { cache: "no-store" })
        const data = (await res.json()) as { projects?: ProjectDeliverable[] }
        if (!cancelled) setProjects(Array.isArray(data.projects) ? data.projects : [])
      } finally {
        if (!cancelled) setIsLoading(false)
      }
    }
    void load()
    return () => { cancelled = true }
  }, [])

  const toggleFollow = async (projectId: string) => {
    const res = await fetch(`/api/projects/${projectId}/actions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "toggleFollow", followerId: userId }),
    })
    if (!res.ok) return
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== projectId) return p
        const followers = p.followers ?? []
        return {
          ...p,
          followers: followers.includes(userId)
            ? followers.filter((f) => f !== userId)
            : [...followers, userId],
        }
      })
    )
  }

  const filtered = filter === "all" ? projects : projects.filter((p) => p.status === filter)
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const safePage = Math.min(page, totalPages)
  const paginated = filtered.slice((safePage - 1) * pageSize, safePage * pageSize)
  const stats = {
    total: projects.length,
    active: projects.filter((p) => p.status === "In Progress").length,
    completed: projects.filter((p) => p.status === "Completed").length,
    avgProgress: projects.length > 0
      ? Math.round(projects.reduce((s, p) => s + p.progress, 0) / projects.length)
      : 0,
  }

  useEffect(() => {
    setPage(1)
  }, [filter])

  useEffect(() => {
    if (page > totalPages) setPage(totalPages)
  }, [page, totalPages])

  const filterOptions = [
    { key: "all" as const,          label: t.filterAll },
    { key: "Planning" as const,     label: t.statusPlanning },
    { key: "In Progress" as const,  label: t.statusInProgress },
    { key: "On Hold" as const,      label: t.statusOnHold },
    { key: "Completed" as const,    label: t.statusCompleted },
  ]

  const kpiCards = [
    { label: t.totalProjects, value: stats.total,              Icon: ChartBar },
    { label: t.active,        value: stats.active,             Icon: Clock },
    { label: t.completed,     value: stats.completed,          Icon: Buildings },
    { label: t.avgProgress,   value: `${stats.avgProgress}%`,  Icon: ArrowRight },
  ]

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">{t.label}</p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">{t.title}</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">{t.description}</p>
      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-4">
        {kpiCards.map((s) => (
          <Card key={s.label} className="rounded-2xl">
            <CardContent className="flex items-center gap-3 pt-5">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <s.Icon className="size-4" />
              </span>
              <div>
                <p className="text-2xl font-bold tabular-nums">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        {filterOptions.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
              filter === key
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-28 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="rounded-2xl">
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            {t.noProjects}
          </CardContent>
        </Card>
      ) : (
        <ul className="space-y-2">
          {paginated.map((project) => {
            const isFollowing = (project.followers ?? []).includes(userId)
            const verifiedMilestones = project.milestones?.filter((m) => m.status === "Verified").length ?? 0
            const totalMilestones = project.milestones?.length ?? 0
            return (
              <li key={project.id} className="group rounded-lg border-b border-border/60 px-1 py-4 transition-colors hover:bg-muted/40 last:border-b-0">
                <div className="mb-2 flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <Badge className={statusStyles[project.status]}>{project.status}</Badge>
                    </div>
                    <h3 className="mt-2 text-base font-semibold leading-snug transition-colors group-hover:text-primary">{project.title}</h3>
                    <p className="text-sm text-muted-foreground">{project.ministry}{project.department ? ` · ${project.department}` : ""}</p>
                  </div>
                  <button
                    onClick={() => void toggleFollow(project.id)}
                    className={`flex size-8 items-center justify-center rounded-full transition-colors ${
                      isFollowing ? "text-amber-500 hover:text-amber-600" : "text-muted-foreground hover:text-amber-500"
                    }`}
                    title={isFollowing ? t.unfollow : t.follow}
                  >
                    <Star className="size-4" weight={isFollowing ? "fill" : "regular"} />
                  </button>
                </div>
                <div className="flex flex-1 flex-col gap-4">
                  <div>
                    <div className="mb-1.5 flex justify-between text-sm">
                      <span className="text-muted-foreground">{t.progress}</span>
                      <span className="font-semibold">{project.progress}%</span>
                    </div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                      <div
                        className={`h-full rounded-full transition-all ${progressBarColor[project.status]}`}
                        style={{ width: `${project.progress}%` }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-y-2 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">{t.owner}</p>
                      <p className="font-medium">{project.owner}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{t.deadline}</p>
                      <p className="font-medium">{project.deadline}</p>
                    </div>
                    {typeof project.budgetAllocatedBdt === "number" && (
                      <>
                        <div>
                          <p className="text-xs text-muted-foreground">{t.allocated}</p>
                          <p className="font-medium">৳ {project.budgetAllocatedBdt.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">{t.spent}</p>
                          <p className="font-medium">৳ {(project.budgetSpentBdt ?? 0).toLocaleString()}</p>
                        </div>
                      </>
                    )}
                  </div>

                  {totalMilestones > 0 && (
                    <div className="rounded-xl bg-muted/40 px-3 py-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">{t.milestones}</span>
                        <span className="font-medium">{verifiedMilestones}/{totalMilestones} {t.verified}</span>
                      </div>
                      <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-green-500"
                          style={{ width: totalMilestones > 0 ? `${(verifiedMilestones / totalMilestones) * 100}%` : "0%" }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </li>
            )
          })}
        </ul>
      )}
      {!isLoading && filtered.length > 0 && (
        <div className="mt-6 flex items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">
            Page {safePage} of {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <button
              type="button"
              className="inline-flex h-8 items-center rounded-md border border-input bg-background px-3 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground disabled:pointer-events-none disabled:opacity-50"
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              Previous
            </button>
            <button
              type="button"
              className="inline-flex h-8 items-center rounded-md border border-input bg-background px-3 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground disabled:pointer-events-none disabled:opacity-50"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
